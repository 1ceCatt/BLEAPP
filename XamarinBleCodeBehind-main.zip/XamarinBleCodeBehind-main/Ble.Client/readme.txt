Xamarin BLE App
For use with Android release 31 or newer
Not tested on IOS

Based on code from Jenx.Si, TaylorM, Dharman and various others
Written by MoThunderz